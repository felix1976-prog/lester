export const config = {
  apiKey: 'AIzaSyAtAQsA7-max7T6WWK0Co079ew2mWp6kn8',
  authDomain: 'triphin-ccbdb.firebaseapp.com',
  databaseURL: 'https://triphin-ccbdb.firebaseio.com',
  projectId: 'triphin-ccbdb',
  storageBucket: 'triphin-ccbdb.appspot.com',
  messagingSenderId: '395196543424'
}
