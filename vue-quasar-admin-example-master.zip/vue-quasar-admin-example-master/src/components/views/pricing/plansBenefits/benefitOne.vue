<template>
  <div class="list ">
    <q-collapsible icon="shopping_basket" label="Citrus">
      <div class="item">
        <div class="item-content">50 Oranges</div>
      </div>
      <div class="item" >
        <div class="item-content">45 Limes</div>
      </div>
    </q-collapsible>
    <q-collapsible icon="favorite" label="Berries">
      <div class="item">
        <div class="item-content">43 Blackberries</div>
      </div>
      <div class="item">
        <div class="item-content">22 Grapes</div>
      </div>
    </q-collapsible>
    <q-collapsible icon="opacity" label="Melons">
      <div class="item" >
        <div class="item-content">5 Watermelon</div>
      </div>
      <div class="item" >
        <div class="item-content">10 Casaba</div>
      </div>
    </q-collapsible>
  </div>
</template>

<script type="text/javascript">
  export default {
    data () {
      return {}
    }
  }
</script>

<style>
</style>
