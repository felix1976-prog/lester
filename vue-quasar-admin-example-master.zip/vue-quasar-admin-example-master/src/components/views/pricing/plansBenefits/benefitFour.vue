<template>
  <div class="list striped">
    <div class="item">
      <div class="item-content">8 Oranges</div>
    </div>
    <div class="item">
      <div class="item-content">6 Limons</div>
    </div>
    <div class="item">
      <div class="item-content">3 Grapes</div>
    </div>

  </div>
</template>

<script type="text/javascript">
export default {
  data () {
    return {}
  }
}
</script>

<style>
</style>
