<template>
  <div class="list">
    <div class="list-label inset">Citrus</div>
    <div class="item">
      <div class="item-content inset">24 Oranges</div>
    </div>
    <div class="item">
      <div class="item-content inset">20 Limes</div>
    </div>
    <hr class="inset">
    <div class="list-label inset">Berries</div>
    <div class="item">
      <div class="item-content inset">20 Blackberries</div>
    </div>
    <div class="item">
      <div class="item-content inset">10 Grapes</div>
    </div>
  </div>
</template>
<script type="text/javascript">
export default {
  data () {
    return {}
  }
}
</script>
<style>
</style>
