export class CreateDonationInput {}
